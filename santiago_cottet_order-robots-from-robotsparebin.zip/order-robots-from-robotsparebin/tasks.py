## Imports
from robocorp.tasks import task
from robocorp import browser
from RPA.Tables import Tables
from RPA.HTTP import HTTP
from RPA.PDF import PDF
from RPA.Archive import Archive


## Core Task
@task
def order_robots_from_RobotSpareBin():
    """
    Orders robots from RobotSpareBin Industries Inc.
    Saves the order HTML receipt as a PDF file.
    Saves the screenshot of the ordered robot.
    Embeds the screenshot of the robot to the PDF receipt.
    Creates ZIP archive of the receipts and the images.
    """
    # Add delay to web interactions
    browser.configure(
        slowmo = 200
    )

    # Robot Steps
    open_robot_order_website()
    get_orders()
    orders_table = read_input_table()
    for row in orders_table:
        success_order = False
        close_annoying_modal()
        fill_the_form(row)
        while success_order is False:
            submit_order()
            success_order = verify_order_execution()
        robot_receipt = obtain_receipt()
        capture_robot_image(row['Order number'])
        generate_order_pdf(row['Order number'], robot_receipt)
        return_to_home_page()
    archive_receipts()

## Functions
# Open Browser
def open_robot_order_website():
    """Navigates to the given URL"""
    browser.goto("https://robotsparebinindustries.com/#/robot-order")

# Download Report
def get_orders():
    """Download Input csv"""
    http = HTTP()
    http.download(url="https://robotsparebinindustries.com/orders.csv", overwrite=True)

# Read csv Report
def read_input_table():
    """Read csv file and return output dt"""
    table = Tables()
    input_table = table.read_table_from_csv(path="orders.csv")
    return input_table

# Close Browser Pop-up
def close_annoying_modal():
    """Close Browser Initial Pop-up"""
    page = browser.page()
    page.click("button:text('I guess so...')")

# Fill Form in Browser
def fill_the_form(input_data):
    """Fill Form in Browser"""
    page = browser.page()
    # Head
    page.select_option("#head", str(input_data["Head"]))
    # Body
    page.click("#id-body-"+ input_data["Body"] +"")
    # Legs
    page.fill("xpath=//input[@type='number']", str(input_data['Legs']))
    # Shipping Address
    page.fill("#address", input_data["Legs"])

# Submit Order
def submit_order():
    """Click on Order Button"""
    page = browser.page()
    page.click("button:text('Order')")

# Verify Order Execution
def verify_order_execution():
    """Sometimes a Bear comes to the server an throws an error. This function verify if there is a bear or not."""
    page = browser.page()
    error_exists = not page.is_visible("xpath=//div[@class='alert alert-danger']")

    return error_exists

# Obtain Receipt
def obtain_receipt():
    """Obtain Receipt Description"""
    page = browser.page()
    receipt = page.locator("#receipt").inner_html()

    return receipt

# Capture Bot Screenshot (Image)
def capture_robot_image(order):
    """Capture Robot Screenshot or Image"""
    page = browser.page()
    page.locator("#robot-preview-image").screenshot(type='png', path=f"robot_images\{order}.png")

# Generate Order PDF
def generate_order_pdf(order, robot_receipt):
    """Generate Order PDF. Must have receipt + robot image"""
    files = [f"robot_images\{order}.png"]
    pdf = PDF()
    pdf.html_to_pdf(robot_receipt, f"output/{order}.pdf")
    pdf.add_files_to_pdf(files=files, target_document=f"output/{order}.pdf", append = True)

# Return to the home page
def return_to_home_page():
    """After obtain order PDF, the robot should go back to the home page to start filling a new form"""
    page = browser.page()
    page.click("button:text('Order another robot')")

# Zip Reports
def archive_receipts():
    """Zip output PDFs"""
    lib = Archive()
    lib.archive_folder_with_zip(folder='output', archive_name='Output.zip', include='*.pdf')
